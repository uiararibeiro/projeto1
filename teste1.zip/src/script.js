alert("Olá Munddo"!)

prompt ("Dgite aqui seu nome:")